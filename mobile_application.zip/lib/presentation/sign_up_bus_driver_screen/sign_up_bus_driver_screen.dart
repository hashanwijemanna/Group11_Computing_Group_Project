import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/widgets/custom_elevated_button.dart';
import 'package:thamal_s_application2/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignUpBusDriverScreen extends StatelessWidget {
  SignUpBusDriverScreen({Key? key}) : super(key: key);

  TextEditingController emailFieldController = TextEditingController();

  TextEditingController phoneNumberFieldController = TextEditingController();

  TextEditingController lockFieldController = TextEditingController();

  TextEditingController vectorFieldController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      _buildSignUpForm(context),
                      SizedBox(height: 76.v),
                      Text("Create Account",
                          style: theme.textTheme.headlineSmall),
                      SizedBox(height: 32.v),
                      _buildEmailField(context),
                      SizedBox(height: 12.v),
                      _buildPhoneNumberField(context),
                      SizedBox(height: 12.v),
                      _buildLockField(context),
                      SizedBox(height: 12.v),
                      _buildVectorField(context),
                      Spacer(),
                      _buildSignUpButton(context),
                      SizedBox(height: 36.v),
                      Text("Already have an account?",
                          style: CustomTextStyles
                              .bodyMediumLexendOnPrimaryContainer),
                      SizedBox(height: 13.v),
                      Text("Sign in from here",
                          style: CustomTextStyles.bodyMediumLexendPrimary),
                      SizedBox(height: 51.v)
                    ])))));
  }

  /// Section Widget
  Widget _buildSignUpForm(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 130.h, vertical: 25.v),
        decoration: AppDecoration.outlineOnPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderBL150),
        child: Container(
            height: 100.adaptSize,
            width: 100.adaptSize,
            decoration: AppDecoration.fillBlueGray
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder30),
            child: CustomImageView(
                imagePath: ImageConstant.imgWhatsappImage,
                height: 83.v,
                width: 100.h,
                alignment: Alignment.topCenter)));
  }

  /// Section Widget
  Widget _buildEmailField(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: emailFieldController,
            hintText: "Email",
            textInputType: TextInputType.emailAddress,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(12.h, 10.v, 19.h, 10.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgVectorPrimary20x24,
                    height: 20.v,
                    width: 24.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildPhoneNumberField(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: phoneNumberFieldController,
            hintText: "Enter your Phone number",
            textInputType: TextInputType.phone,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(12.h, 11.v, 25.h, 11.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgComponent6,
                    height: 18.adaptSize,
                    width: 18.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildLockField(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: lockFieldController,
            prefix: Container(
                padding: EdgeInsets.fromLTRB(11.h, 9.v, 30.h, 9.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgLock,
                    height: 22.v,
                    width: 19.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v),
            suffix: Container(
                padding: EdgeInsets.fromLTRB(30.h, 12.v, 12.h, 13.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgInfo,
                    height: 15.v,
                    width: 22.h)),
            suffixConstraints: BoxConstraints(maxHeight: 40.v),
            obscureText: true));
  }

  /// Section Widget
  Widget _buildVectorField(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: vectorFieldController,
            textInputAction: TextInputAction.done,
            prefix: Container(
                padding: EdgeInsets.fromLTRB(12.h, 9.v, 30.h, 10.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgVector,
                    height: 21.v,
                    width: 16.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v),
            suffix: Container(
                padding: EdgeInsets.fromLTRB(30.h, 12.v, 12.h, 13.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgInfo,
                    height: 15.v,
                    width: 22.h)),
            suffixConstraints: BoxConstraints(maxHeight: 40.v),
            obscureText: true));
  }

  /// Section Widget
  Widget _buildSignUpButton(BuildContext context) {
    return CustomElevatedButton(
        text: "SIGN UP",
        margin: EdgeInsets.symmetric(horizontal: 25.h),
        onPressed: () {
          onTapSignUpButton(context);
        });
  }

  /// Navigates to the signInScreen when the action is triggered.
  onTapSignUpButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInScreen);
  }
}
