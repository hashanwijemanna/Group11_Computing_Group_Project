import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';

class BusDriverProfileScreen extends StatelessWidget {
  BusDriverProfileScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 10.h,
            vertical: 11.v,
          ),
          child: Column(
            children: [
              _buildMenuRow(context),
              SizedBox(height: 39.v),
              Text(
                "PROFILE",
                style: theme.textTheme.titleLarge,
              ),
              SizedBox(height: 28.v),
              Container(
                width: 116.h,
                margin: EdgeInsets.symmetric(horizontal: 112.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 21.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.fillBlueGray.copyWith(
                  borderRadius: BorderRadiusStyle.circleBorder58,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(height: 21.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgUserBlue80060x60,
                      height: 53.adaptSize,
                      width: 53.adaptSize,
                    ),
                    SizedBox(height: 6.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgCamera,
                      height: 15.adaptSize,
                      width: 15.adaptSize,
                      alignment: Alignment.centerRight,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 50.v),
              _buildNameRow(context),
              SizedBox(height: 13.v),
              _buildNICRow(context),
              SizedBox(height: 13.v),
              _buildEmailRow(context),
              SizedBox(height: 14.v),
              _buildMobileRow(context),
              SizedBox(height: 14.v),
              _buildHomePhoneRow(context),
              SizedBox(height: 13.v),
              _buildDateOfBirthRow(context),
              SizedBox(height: 13.v),
              _buildAddressRow(context),
              SizedBox(height: 12.v),
              _buildDistrictRow(context),
              SizedBox(height: 11.v),
              _buildProvinceRow(context),
              SizedBox(height: 15.v),
              _buildBusIDRow(context),
              SizedBox(height: 36.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Padding(
                  padding: EdgeInsets.only(left: 10.h),
                  child: Text(
                    "Bus owner Details",
                    style: CustomTextStyles.bodySmall12,
                  ),
                ),
              ),
              SizedBox(height: 21.v),
              _buildNameRow1(context),
              SizedBox(height: 13.v),
              _buildBusOwnerIDRow(context),
              SizedBox(height: 15.v),
              _buildBusIDRow1(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 10.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgMenu,
            height: 12.v,
            width: 18.h,
            margin: EdgeInsets.symmetric(vertical: 14.v),
          ),
          Container(
            height: 40.adaptSize,
            width: 40.adaptSize,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(
                20.h,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNameRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Name: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 64.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNICRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "NIC: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 74.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildEmailRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Email: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 66.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMobileRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Mobile:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 61.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildHomePhoneRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Home Phone:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 31.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDateOfBirthRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Date of birth:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 31.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAddressRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Address:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(
              left: 55.h,
              bottom: 2.v,
            ),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildDistrictRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.only(top: 1.v),
            child: Text(
              "District:",
              style: theme.textTheme.bodySmall,
            ),
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(
              left: 58.h,
              bottom: 3.v,
            ),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildProvinceRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: EdgeInsets.only(top: 2.v),
            child: Text(
              "Province:",
              style: theme.textTheme.bodySmall,
            ),
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(
              left: 51.h,
              bottom: 4.v,
            ),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBusIDRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildNinety(
            context,
            busGroupID: "Bus Group ID",
            busGroupID1: "Bus Group ID",
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(
              left: 30.h,
              bottom: 2.v,
            ),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNameRow1(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Name:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 64.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBusOwnerIDRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Bus Owner ID: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 26.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBusIDRow1(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildNinety(
            context,
            busGroupID: "Bus Group ID",
            busGroupID1: "Bus Group ID",
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(
              left: 30.h,
              bottom: 2.v,
            ),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildNinety(
    BuildContext context, {
    required String busGroupID,
    required String busGroupID1,
  }) {
    return SizedBox(
      height: 13.v,
      width: 66.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.center,
            child: Text(
              busGroupID,
              style: theme.textTheme.bodySmall!.copyWith(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              busGroupID1,
              style: theme.textTheme.bodySmall!.copyWith(
                color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
