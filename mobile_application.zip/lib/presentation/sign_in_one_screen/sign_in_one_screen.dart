import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignInOneScreen extends StatelessWidget {
  SignInOneScreen({Key? key}) : super(key: key);

  TextEditingController userTypeController = TextEditingController();

  TextEditingController userTypeParentController = TextEditingController();

  TextEditingController userTypeAdminController = TextEditingController();

  TextEditingController userTypeBusOwnerController = TextEditingController();

  TextEditingController userTypeBusDriverController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  _buildSignInOneStack(context),
                  Spacer(flex: 51),
                  Text("You are a,", style: theme.textTheme.headlineSmall),
                  SizedBox(height: 18.v),
                  _buildUserType(context),
                  SizedBox(height: 11.v),
                  _buildUserTypeParent(context),
                  SizedBox(height: 11.v),
                  _buildUserTypeAdmin(context),
                  SizedBox(height: 11.v),
                  _buildUserTypeBusOwner(context),
                  SizedBox(height: 11.v),
                  _buildUserTypeBusDriver(context),
                  Spacer(flex: 48),
                  Text("Already have an account?",
                      style:
                          CustomTextStyles.bodyMediumLexendOnPrimaryContainer),
                  SizedBox(height: 13.v),
                  GestureDetector(
                      onTap: () {
                        onTapTxtSignInFromHere(context);
                      },
                      child: Text("Sign in from here",
                          style: CustomTextStyles.bodyMediumLexendPrimary)),
                  SizedBox(height: 51.v)
                ]))));
  }

  /// Section Widget
  Widget _buildSignInOneStack(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 130.h, vertical: 25.v),
        decoration: AppDecoration.outlineOnPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderBL150),
        child: Container(
            height: 100.adaptSize,
            width: 100.adaptSize,
            decoration: AppDecoration.fillBlueGray
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder30),
            child: CustomImageView(
                imagePath: ImageConstant.imgWhatsappImage,
                height: 83.v,
                width: 100.h,
                alignment: Alignment.topCenter)));
  }

  /// Section Widget
  Widget _buildUserType(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: userTypeController,
            hintText: "Student",
            prefix: Container(
                margin: EdgeInsets.fromLTRB(15.h, 11.v, 29.h, 11.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgVectorOnprimarycontainer,
                    height: 18.v,
                    width: 16.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildUserTypeParent(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: userTypeParentController,
            hintText: "Parent",
            prefix: Container(
                margin: EdgeInsets.fromLTRB(11.h, 8.v, 25.h, 8.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgAccountoutline,
                    height: 24.adaptSize,
                    width: 24.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildUserTypeAdmin(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: userTypeAdminController,
            hintText: "Admin",
            prefix: Container(
                margin: EdgeInsets.fromLTRB(15.h, 10.v, 29.h, 10.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgUserOnprimarycontainer,
                    height: 18.v,
                    width: 16.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildUserTypeBusOwner(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: userTypeBusOwnerController,
            hintText: "Bus Owner",
            prefix: Container(
                margin: EdgeInsets.fromLTRB(11.h, 8.v, 25.h, 8.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgAccountoutline,
                    height: 24.adaptSize,
                    width: 24.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildUserTypeBusDriver(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: userTypeBusDriverController,
            hintText: "Bus Driver",
            textInputAction: TextInputAction.done,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(11.h, 8.v, 25.h, 8.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgAccountoutline,
                    height: 24.adaptSize,
                    width: 24.adaptSize)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Navigates to the signInScreen when the action is triggered.
  onTapTxtSignInFromHere(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInScreen);
  }
}
