import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/app_bar/appbar_image.dart';
import 'package:thamal_s_application2/widgets/app_bar/custom_app_bar.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';
import 'package:thamal_s_application2/widgets/custom_rating_bar.dart';

class BusDetailsEachScreen extends StatelessWidget {
  BusDetailsEachScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 14.h,
            vertical: 35.v,
          ),
          child: Column(
            children: [
              Container(
                height: 140.v,
                width: 200.h,
                decoration: BoxDecoration(
                  color: appTheme.blueGray100,
                  borderRadius: BorderRadius.circular(
                    5.h,
                  ),
                ),
              ),
              SizedBox(height: 10.v),
              CustomRatingBar(
                initialRating: 0,
              ),
              SizedBox(height: 46.v),
              _buildDriverName(context),
              SizedBox(height: 14.v),
              _buildEmail(context),
              SizedBox(height: 14.v),
              _buildMobile(context),
              SizedBox(height: 14.v),
              _buildLicensePlateNumber(context),
              SizedBox(height: 15.v),
              _buildBusId(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      title: Container(
        width: 300.h,
        margin: EdgeInsets.only(left: 4.h),
        padding: EdgeInsets.all(8.h),
        decoration: AppDecoration.fillBlueGray.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder17,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppbarImage(
              imagePath: ImageConstant.imgMenu,
              margin: EdgeInsets.only(
                left: 3.h,
                top: 3.v,
                bottom: 4.v,
              ),
            ),
            AppbarImage(
              imagePath: ImageConstant.imgSearch,
              margin: EdgeInsets.only(
                left: 246.h,
                bottom: 2.v,
              ),
            ),
          ],
        ),
      ),
      actions: [
        Container(
          height: 40.adaptSize,
          width: 40.adaptSize,
          margin: EdgeInsets.fromLTRB(6.h, 8.v, 10.h, 8.v),
          decoration: BoxDecoration(
            color: appTheme.blueGray100,
            borderRadius: BorderRadius.circular(
              20.h,
            ),
          ),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildDriverName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Driver’s Name: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 199.h,
            margin: EdgeInsets.only(top: 2.v),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Email: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 199.h,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildMobile(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Mobile:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 199.h,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildLicensePlateNumber(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Licences Plate Number:",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 199.h,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBusId(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            height: 13.v,
            width: 66.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Bus Group ID",
                    style: theme.textTheme.bodySmall,
                  ),
                ),
                Align(
                  alignment: Alignment.center,
                  child: Text(
                    "Bus Group ID",
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 11.v,
            width: 199.h,
            margin: EdgeInsets.only(bottom: 2.v),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
