import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/widgets/custom_checkbox_button.dart';
import 'package:thamal_s_application2/widgets/custom_elevated_button.dart';
import 'package:thamal_s_application2/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignInScreen extends StatelessWidget {
  SignInScreen({Key? key}) : super(key: key);

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  bool englishName = false;

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      _buildSignInForm(context),
                      Spacer(flex: 51),
                      Text("Sign in Now", style: theme.textTheme.headlineSmall),
                      SizedBox(height: 40.v),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 25.h),
                          child: CustomTextFormField(
                              controller: userNameController,
                              hintText: "Username",
                              prefix: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      14.h, 12.v, 30.h, 12.v),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgUser,
                                      height: 16.adaptSize,
                                      width: 16.adaptSize)),
                              prefixConstraints:
                                  BoxConstraints(maxHeight: 40.v))),
                      SizedBox(height: 10.v),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 25.h),
                          child: CustomTextFormField(
                              controller: passwordController,
                              hintText: "Password",
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              prefix: Container(
                                  margin:
                                      EdgeInsets.fromLTRB(14.h, 9.v, 30.h, 9.v),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgVector,
                                      height: 21.v,
                                      width: 16.h)),
                              prefixConstraints:
                                  BoxConstraints(maxHeight: 40.v),
                              suffix: Container(
                                  margin: EdgeInsets.fromLTRB(
                                      30.h, 12.v, 7.h, 12.v),
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgInfo,
                                      height: 15.v,
                                      width: 22.h)),
                              suffixConstraints:
                                  BoxConstraints(maxHeight: 40.v),
                              obscureText: true,
                              contentPadding:
                                  EdgeInsets.symmetric(vertical: 11.v))),
                      SizedBox(height: 14.v),
                      _buildRememberMeRow(context),
                      Spacer(flex: 48),
                      CustomElevatedButton(
                          text: "SIGN IN",
                          margin: EdgeInsets.symmetric(horizontal: 25.h),
                          onPressed: () {
                            onTapSIGNIN(context);
                          }),
                      SizedBox(height: 44.v),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: EdgeInsets.only(right: 76.h),
                              child: Text("Don’t you have an account?",
                                  style: CustomTextStyles
                                      .bodyMediumLexendOnPrimaryContainer))),
                      SizedBox(height: 12.v),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding: EdgeInsets.only(right: 109.h),
                              child: Text("Sign up from here",
                                  style: CustomTextStyles
                                      .bodyMediumLexendPrimary))),
                      SizedBox(height: 70.v)
                    ])))));
  }

  /// Section Widget
  Widget _buildSignInForm(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 130.h, vertical: 25.v),
        decoration: AppDecoration.outlineOnPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderBL150),
        child: Container(
            height: 100.adaptSize,
            width: 100.adaptSize,
            decoration: AppDecoration.fillBlueGray
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder30),
            child: CustomImageView(
                imagePath: ImageConstant.imgWhatsappImage,
                height: 83.v,
                width: 100.h,
                alignment: Alignment.topCenter)));
  }

  /// Section Widget
  Widget _buildRememberMeRow(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 25.h, right: 31.h),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Padding(
              padding: EdgeInsets.only(bottom: 1.v),
              child: CustomCheckboxButton(
                  text: "Remember me",
                  value: englishName,
                  onChange: (value) {
                    englishName = value;
                  })),
          Text("Forgot Password?",
              textAlign: TextAlign.center, style: CustomTextStyles.bodySmall11)
        ]));
  }

  /// Navigates to the studentDashboardScreen when the action is triggered.
  onTapSIGNIN(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.studentDashboardScreen);
  }
}
