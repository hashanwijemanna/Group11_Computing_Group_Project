import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';

class AppNavigationScreen extends StatelessWidget {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(context),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          context,
                          busText: "Sign-in",
                          onTapScreenTitle: () =>
                              onTapScreenTitle(context, AppRoutes.signInScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus Details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus Details-each",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busDetailsEachScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Driver Details",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.driverDetailsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Driver Details-each",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.driverDetailsEachScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Feedbacks",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.feedbacksScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Reports",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.reportsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Map- Student & Parent",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.mapStudentParentScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Map -Bus owner & bus driver",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.mapBusOwnerBusDriverScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Route details - Container",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.routeDetailsContainerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "My Alerts",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.myAlertsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Notifications",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.notificationsScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "First UI",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.firstUiScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Login/Home",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.loginHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-in One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signInOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Student-Dashboard",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.studentDashboardScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Parent-Home",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.parentHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Student Administration-Home",
                          onTapScreenTitle: () => onTapScreenTitle(context,
                              AppRoutes.studentAdministrationHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus Owner-Home",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busOwnerHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus Driver-Home",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busDriverHomeScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Student Attendance",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.studentAttendanceScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-up/student",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signUpStudentScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-up/Parent",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signUpParentScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-up/Admin",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signUpAdminScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Stu.Ad-Announcement One",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.stuAdAnnouncementOneScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Stu.Ad-Announcement",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.stuAdAnnouncementScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Student-Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.studentProfileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Parent-Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.parentProfileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Student Admin-Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.studentAdminProfileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus owner-Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busOwnerProfileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Bus Driver-Profile",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.busDriverProfileScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "My Activity-Student",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.myActivityStudentScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-up/Bus Owner",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signUpBusOwnerScreen),
                        ),
                        _buildScreenTitle(
                          context,
                          busText: "Sign-up/Bus Driver",
                          onTapScreenTitle: () => onTapScreenTitle(
                              context, AppRoutes.signUpBusDriverScreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle(
    BuildContext context, {
    required String busText,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  busText,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(
    BuildContext context,
    String routeName,
  ) {
    Navigator.pushNamed(context, routeName);
  }
}
