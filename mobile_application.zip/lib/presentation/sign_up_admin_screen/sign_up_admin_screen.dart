import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/widgets/custom_elevated_button.dart';
import 'package:thamal_s_application2/widgets/custom_text_form_field.dart';

// ignore_for_file: must_be_immutable
class SignUpAdminScreen extends StatelessWidget {
  SignUpAdminScreen({Key? key}) : super(key: key);

  TextEditingController emailEditTextController = TextEditingController();

  TextEditingController lockEditTextController = TextEditingController();

  TextEditingController vectorEditTextController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: Column(children: [
                      _buildElevenStack(context),
                      SizedBox(height: 76.v),
                      Text("Create Account",
                          style: theme.textTheme.headlineSmall),
                      SizedBox(height: 32.v),
                      _buildEmailEditText(context),
                      SizedBox(height: 23.v),
                      _buildLockEditText(context),
                      SizedBox(height: 23.v),
                      _buildVectorEditText(context),
                      Spacer(),
                      _buildSignupButton(context),
                      SizedBox(height: 36.v),
                      Text("Already have an account?",
                          style: CustomTextStyles
                              .bodyMediumLexendOnPrimaryContainer),
                      SizedBox(height: 13.v),
                      GestureDetector(
                          onTap: () {
                            onTapTxtSignInFromHere(context);
                          },
                          child: Text("Sign in from here",
                              style: CustomTextStyles.bodyMediumLexendPrimary)),
                      SizedBox(height: 51.v)
                    ])))));
  }

  /// Section Widget
  Widget _buildElevenStack(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 130.h, vertical: 25.v),
        decoration: AppDecoration.outlineOnPrimaryContainer
            .copyWith(borderRadius: BorderRadiusStyle.customBorderBL150),
        child: Container(
            height: 100.adaptSize,
            width: 100.adaptSize,
            decoration: AppDecoration.fillBlueGray
                .copyWith(borderRadius: BorderRadiusStyle.roundedBorder30),
            child: CustomImageView(
                imagePath: ImageConstant.imgWhatsappImage,
                height: 83.v,
                width: 100.h,
                alignment: Alignment.topCenter)));
  }

  /// Section Widget
  Widget _buildEmailEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: emailEditTextController,
            hintText: "Email",
            textInputType: TextInputType.emailAddress,
            prefix: Container(
                margin: EdgeInsets.fromLTRB(12.h, 10.v, 19.h, 10.v),
                child: CustomImageView(
                    imagePath: ImageConstant.imgVectorPrimary20x24,
                    height: 20.v,
                    width: 24.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v)));
  }

  /// Section Widget
  Widget _buildLockEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: lockEditTextController,
            prefix: Container(
                padding: EdgeInsets.fromLTRB(11.h, 9.v, 30.h, 9.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgLock,
                    height: 22.v,
                    width: 19.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v),
            suffix: Container(
                padding: EdgeInsets.fromLTRB(30.h, 12.v, 12.h, 13.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgInfo,
                    height: 15.v,
                    width: 22.h)),
            suffixConstraints: BoxConstraints(maxHeight: 40.v),
            obscureText: true));
  }

  /// Section Widget
  Widget _buildVectorEditText(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 25.h),
        child: CustomTextFormField(
            controller: vectorEditTextController,
            textInputAction: TextInputAction.done,
            prefix: Container(
                padding: EdgeInsets.fromLTRB(13.h, 10.v, 30.h, 9.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgVector,
                    height: 21.v,
                    width: 16.h)),
            prefixConstraints: BoxConstraints(maxHeight: 40.v),
            suffix: Container(
                padding: EdgeInsets.fromLTRB(30.h, 13.v, 12.h, 12.v),
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    borderRadius: BorderRadius.circular(20.h),
                    boxShadow: [
                      BoxShadow(
                          color: theme.colorScheme.onPrimaryContainer,
                          spreadRadius: 2.h,
                          blurRadius: 2.h,
                          offset: Offset(0, 4))
                    ]),
                child: CustomImageView(
                    imagePath: ImageConstant.imgInfo,
                    height: 15.v,
                    width: 22.h)),
            suffixConstraints: BoxConstraints(maxHeight: 40.v),
            obscureText: true));
  }

  /// Section Widget
  Widget _buildSignupButton(BuildContext context) {
    return CustomElevatedButton(
        text: "SIGN UP",
        margin: EdgeInsets.symmetric(horizontal: 25.h),
        onPressed: () {
          onTapSignupButton(context);
        });
  }

  /// Navigates to the signInScreen when the action is triggered.
  onTapSignupButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInScreen);
  }

  /// Navigates to the signInScreen when the action is triggered.
  onTapTxtSignInFromHere(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInScreen);
  }
}
