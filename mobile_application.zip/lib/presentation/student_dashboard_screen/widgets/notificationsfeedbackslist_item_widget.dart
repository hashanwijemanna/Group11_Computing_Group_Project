import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';

// ignore: must_be_immutable
class NotificationsfeedbackslistItemWidget extends StatelessWidget {
  NotificationsfeedbackslistItemWidget({
    Key? key,
    this.onTapImgNotificationsImage,
    this.onTapImgFeedbacksImage,
  }) : super(
          key: key,
        );

  VoidCallback? onTapImgNotificationsImage;

  VoidCallback? onTapImgFeedbacksImage;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100.h,
      child: Padding(
        padding: EdgeInsets.only(bottom: 1.v),
        child: Column(
          children: [
            SizedBox(
              height: 112.v,
              width: 100.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgRectangle22,
                    height: 100.adaptSize,
                    width: 100.adaptSize,
                    radius: BorderRadius.circular(
                      10.h,
                    ),
                    alignment: Alignment.topCenter,
                    onTap: () {
                      onTapImgNotificationsImage!.call();
                    },
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      "Notifications",
                      style: theme.textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 31.v),
            SizedBox(
              height: 112.v,
              width: 100.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgRectangle23,
                    height: 100.adaptSize,
                    width: 100.adaptSize,
                    radius: BorderRadius.circular(
                      10.h,
                    ),
                    alignment: Alignment.topCenter,
                    onTap: () {
                      onTapImgFeedbacksImage!.call();
                    },
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      "Feedbacks",
                      style: theme.textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
