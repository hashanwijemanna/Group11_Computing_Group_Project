import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';

class StudentAttendanceScreen extends StatelessWidget {
  StudentAttendanceScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 10.h,
            vertical: 11.v,
          ),
          child: Column(
            children: [
              _buildMenuRow(context),
              SizedBox(height: 13.v),
              Text(
                "PROFILE",
                style: theme.textTheme.titleLarge,
              ),
              SizedBox(height: 35.v),
              Container(
                height: 116.adaptSize,
                width: 116.adaptSize,
                padding: EdgeInsets.all(28.h),
                decoration: AppDecoration.fillBlueGray.copyWith(
                  borderRadius: BorderRadiusStyle.circleBorder58,
                ),
                child: CustomImageView(
                  imagePath: ImageConstant.imgUserBlue80060x60,
                  height: 60.adaptSize,
                  width: 60.adaptSize,
                  alignment: Alignment.center,
                ),
              ),
              SizedBox(height: 56.v),
              SizedBox(
                width: 136.h,
                child: Text(
                  "Attendance Maker ",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.headlineSmall,
                ),
              ),
              SizedBox(height: 15.v),
              CustomImageView(
                imagePath: ImageConstant.imgRectangle23120x120,
                height: 120.adaptSize,
                width: 120.adaptSize,
                radius: BorderRadius.circular(
                  5.h,
                ),
              ),
              SizedBox(height: 39.v),
              CustomImageView(
                imagePath: ImageConstant.imgQrcodeScan,
                height: 40.adaptSize,
                width: 40.adaptSize,
              ),
              SizedBox(height: 4.v),
              Text(
                "Scan",
                style: CustomTextStyles.bodyMediumLexendPrimary,
              ),
              SizedBox(height: 69.v),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgRectangle2450x50,
                    height: 50.adaptSize,
                    width: 50.adaptSize,
                    radius: BorderRadius.circular(
                      5.h,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                      left: 14.h,
                      top: 18.v,
                      bottom: 18.v,
                    ),
                    child: Text(
                      "Attendance",
                      style: theme.textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(
            left: 14.h,
            right: 10.h,
          ),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 11.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgMenu,
            height: 12.v,
            width: 18.h,
            margin: EdgeInsets.only(
              top: 8.v,
              bottom: 20.v,
            ),
          ),
          Container(
            height: 40.adaptSize,
            width: 40.adaptSize,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(
                20.h,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
