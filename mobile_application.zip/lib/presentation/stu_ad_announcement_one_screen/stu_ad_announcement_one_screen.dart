import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';
import 'package:thamal_s_application2/widgets/custom_elevated_button.dart';

class StuAdAnnouncementOneScreen extends StatelessWidget {
  StuAdAnnouncementOneScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 8.h,
            vertical: 15.v,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  height: 40.adaptSize,
                  width: 40.adaptSize,
                  margin: EdgeInsets.only(right: 2.h),
                  decoration: BoxDecoration(
                    color: appTheme.blueGray100,
                    borderRadius: BorderRadius.circular(
                      20.h,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 19.v),
              _buildMenuRow(context),
              SizedBox(height: 16.v),
              _buildNewAnnouncementRow(context),
              SizedBox(height: 15.v),
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: 200.adaptSize,
                  width: 200.adaptSize,
                  decoration: BoxDecoration(
                    color: appTheme.blueGray100,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 52.v),
              Padding(
                padding: EdgeInsets.only(left: 78.h),
                child: Text(
                  "Announcement tittle",
                  style: CustomTextStyles.bodyMediumLexendOnPrimaryContainer13,
                ),
              ),
              SizedBox(height: 16.v),
              Container(
                height: 35.v,
                width: 340.h,
                decoration: BoxDecoration(
                  color: appTheme.blueGray100,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 14.v),
              Padding(
                padding: EdgeInsets.only(left: 78.h),
                child: Text(
                  "Additional comments",
                  style: CustomTextStyles.bodyMediumLexendOnPrimaryContainer13,
                ),
              ),
              SizedBox(height: 20.v),
              Container(
                height: 153.v,
                width: 340.h,
                margin: EdgeInsets.only(left: 2.h),
                decoration: BoxDecoration(
                  color: appTheme.blueGray100,
                  borderRadius: BorderRadius.circular(
                    10.h,
                  ),
                ),
              ),
              SizedBox(height: 14.v),
              CustomElevatedButton(
                text: "Submit ",
                margin: EdgeInsets.symmetric(horizontal: 17.h),
                buttonStyle: CustomButtonStyles.fillPrimary,
                buttonTextStyle: CustomTextStyles.headlineSmallInterWhiteA700,
                alignment: Alignment.center,
              ),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 2.h,
        right: 14.h,
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: 10.h,
              vertical: 11.v,
            ),
            decoration: AppDecoration.fillBlueGray.copyWith(
              borderRadius: BorderRadiusStyle.roundedBorder17,
            ),
            child: CustomImageView(
              imagePath: ImageConstant.imgMenu,
              height: 12.v,
              width: 18.h,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgSearch,
            height: 17.adaptSize,
            width: 17.adaptSize,
            margin: EdgeInsets.only(
              left: 10.h,
              top: 9.v,
              bottom: 8.v,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNewAnnouncementRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            margin: EdgeInsets.symmetric(vertical: 5.v),
            padding: EdgeInsets.symmetric(
              horizontal: 1.h,
              vertical: 2.v,
            ),
            decoration: AppDecoration.fillBlueGray.copyWith(
              borderRadius: BorderRadiusStyle.circleBorder10,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  "New Announcement",
                  style: CustomTextStyles.bodySmall12,
                ),
                Container(
                  height: 10.adaptSize,
                  width: 10.adaptSize,
                  margin: EdgeInsets.only(
                    left: 5.h,
                    top: 2.v,
                    bottom: 2.v,
                  ),
                  decoration: BoxDecoration(
                    color: appTheme.lightGreen500,
                    borderRadius: BorderRadius.circular(
                      5.h,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 30.v,
            child: VerticalDivider(
              width: 1.h,
              thickness: 1.v,
            ),
          ),
          Container(
            width: 140.h,
            margin: EdgeInsets.symmetric(vertical: 5.v),
            padding: EdgeInsets.symmetric(
              horizontal: 23.h,
              vertical: 2.v,
            ),
            decoration: AppDecoration.fillBlueGray.copyWith(
              borderRadius: BorderRadiusStyle.circleBorder10,
            ),
            child: Text(
              "Announcements",
              style: CustomTextStyles.bodySmall12,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
