import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';

// ignore_for_file: must_be_immutable
class BusDriverHomeScreen extends StatelessWidget {
  BusDriverHomeScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
                width: mediaQueryData.size.width,
                height: mediaQueryData.size.height,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGroup282),
                        fit: BoxFit.cover)),
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 5.h, vertical: 11.v),
                    child: Column(children: [
                      Align(
                          alignment: Alignment.centerRight,
                          child: Container(
                              height: 40.adaptSize,
                              width: 40.adaptSize,
                              margin: EdgeInsets.only(right: 5.h),
                              decoration: BoxDecoration(
                                  color: appTheme.blueGray100,
                                  borderRadius: BorderRadius.circular(20.h)))),
                      SizedBox(height: 19.v),
                      _buildMenuRow(context),
                      SizedBox(height: 33.v),
                      _buildDriverDetailsRow(context),
                      Align(
                          alignment: Alignment.centerRight,
                          child: Padding(
                              padding:
                                  EdgeInsets.only(left: 104.h, right: 18.h),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Map",
                                        style: CustomTextStyles.bodySmallLight),
                                    Text("Route Details",
                                        style: theme.textTheme.bodySmall)
                                  ]))),
                      SizedBox(height: 13.v),
                      _buildNotificationsRow(context),
                      SizedBox(height: 5.v)
                    ]))),
            bottomNavigationBar: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.h),
                child: _buildBottomBar(context))));
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Align(
        alignment: Alignment.centerLeft,
        child: Padding(
            padding: EdgeInsets.only(left: 5.h, right: 17.h),
            child: Row(children: [
              Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 10.h, vertical: 11.v),
                  decoration: AppDecoration.fillLightBlueA.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder17),
                  child: CustomImageView(
                      imagePath: ImageConstant.imgMenuBlue800,
                      height: 12.v,
                      width: 18.h)),
              CustomImageView(
                  imagePath: ImageConstant.imgSearchBlue800,
                  height: 17.adaptSize,
                  width: 17.adaptSize,
                  margin: EdgeInsets.only(left: 10.h, top: 9.v, bottom: 8.v))
            ])));
  }

  /// Section Widget
  Widget _buildDriverDetailsRow(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      CustomImageView(
          imagePath: ImageConstant.imgRectangle16,
          height: 233.v,
          width: 230.h,
          radius: BorderRadius.circular(10.h),
          onTap: () {
            onTapImgImage(context);
          }),
      Padding(
          padding: EdgeInsets.only(top: 3.v),
          child: Column(children: [
            CustomImageView(
                imagePath: ImageConstant.imgRectangle291,
                height: 100.adaptSize,
                width: 100.adaptSize,
                radius: BorderRadius.circular(10.h)),
            Text("Driver Details", style: theme.textTheme.bodySmall),
            SizedBox(height: 16.v),
            CustomImageView(
                imagePath: ImageConstant.imgRectangle21,
                height: 100.adaptSize,
                width: 100.adaptSize,
                radius: BorderRadius.circular(10.h),
                onTap: () {
                  onTapImgImage1(context);
                })
          ]))
    ]);
  }

  /// Section Widget
  Widget _buildNotificationsRow(BuildContext context) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Padding(
          padding: EdgeInsets.only(bottom: 1.v),
          child: Column(children: [
            _buildFeedbacks(context,
                userImage: ImageConstant.imgRectangle22,
                feedbackLabel: "Notifications", onTapImage: () {
              onTapImage(context);
            }),
            SizedBox(height: 31.v),
            _buildFeedbacks(context,
                userImage: ImageConstant.imgRectangle23,
                feedbackLabel: "Feedbacks", onTapImage: () {
              onTapImage1(context);
            })
          ])),
      Column(children: [
        CustomImageView(
            imagePath: ImageConstant.imgRectangle24,
            height: 100.adaptSize,
            width: 100.adaptSize,
            radius: BorderRadius.circular(10.h),
            onTap: () {
              onTapImgImage4(context);
            }),
        Text("My Alerts", style: theme.textTheme.bodySmall),
        SizedBox(height: 30.v),
        CustomImageView(
            imagePath: ImageConstant.imgRectangle28,
            height: 100.adaptSize,
            width: 100.adaptSize,
            radius: BorderRadius.circular(10.h),
            onTap: () {
              onTapImgImage5(context);
            }),
        SizedBox(height: 1.v),
        Text("Report", style: theme.textTheme.bodySmall)
      ]),
      Padding(
          padding: EdgeInsets.only(bottom: 145.v),
          child: _buildFeedbacks(context,
              userImage: ImageConstant.imgRectangle30,
              feedbackLabel: "Bus Details", onTapImage: () {
            onTapImage2(context);
          }))
    ]);
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(onChanged: (BottomBarEnum type) {
      Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
    });
  }

  /// Common widget
  Widget _buildFeedbacks(
    BuildContext context, {
    required String userImage,
    required String feedbackLabel,
    Function? onTapImage,
  }) {
    return SizedBox(
        height: 112.v,
        width: 100.h,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          CustomImageView(
              imagePath: userImage,
              height: 100.adaptSize,
              width: 100.adaptSize,
              radius: BorderRadius.circular(10.h),
              alignment: Alignment.topCenter,
              onTap: () {
                onTapImage!.call();
              }),
          Align(
              alignment: Alignment.bottomCenter,
              child: Text(feedbackLabel,
                  style: theme.textTheme.bodySmall!.copyWith(
                      color:
                          theme.colorScheme.onPrimaryContainer.withOpacity(1))))
        ]));
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }

  /// Navigates to the mapBusOwnerBusDriverScreen when the action is triggered.
  onTapImgImage(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.mapBusOwnerBusDriverScreen);
  }

  /// Navigates to the routeDetailsContainerScreen when the action is triggered.
  onTapImgImage1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.routeDetailsContainerScreen);
  }

  /// Navigates to the notificationsScreen when the action is triggered.
  onTapImage(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.notificationsScreen);
  }

  /// Navigates to the feedbacksScreen when the action is triggered.
  onTapImage1(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.feedbacksScreen);
  }

  /// Navigates to the myAlertsScreen when the action is triggered.
  onTapImgImage4(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.myAlertsScreen);
  }

  /// Navigates to the reportsScreen when the action is triggered.
  onTapImgImage5(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.reportsScreen);
  }

  /// Navigates to the busDetailsScreen when the action is triggered.
  onTapImage2(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.busDetailsScreen);
  }
}
