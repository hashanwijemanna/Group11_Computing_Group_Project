import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';

class MyActivityStudentScreen extends StatelessWidget {
  MyActivityStudentScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 39.h,
            vertical: 33.v,
          ),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 11.h,
                  vertical: 3.v,
                ),
                decoration: AppDecoration.fillWhiteA,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "November",
                        style: CustomTextStyles.bodyMediumOnPrimaryContainer,
                      ),
                    ),
                    SizedBox(height: 9.v),
                    Padding(
                      padding: EdgeInsets.only(right: 124.h),
                      child: Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 6.v),
                            child: Text(
                              "1",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Spacer(),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 6.v),
                            child: Text(
                              "1",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Container(
                            width: 30.adaptSize,
                            margin: EdgeInsets.only(left: 23.h),
                            padding: EdgeInsets.symmetric(
                              horizontal: 11.h,
                              vertical: 6.v,
                            ),
                            decoration: AppDecoration.fillBlue500.copyWith(
                              borderRadius: BorderRadiusStyle.roundedBorder17,
                            ),
                            child: Text(
                              "1",
                              style: CustomTextStyles.bodyMediumWhiteA700,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              left: 12.h,
                              bottom: 13.v,
                            ),
                            child: Text(
                              "SUN".toUpperCase(),
                              style: CustomTextStyles.bodySmallRobotoGray600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 16.v),
                  ],
                ),
              ),
              SizedBox(height: 7.v),
              Container(
                padding: EdgeInsets.symmetric(vertical: 3.v),
                decoration: AppDecoration.fillWhiteA,
                child: Column(
                  children: [
                    Text(
                      "November",
                      style: CustomTextStyles.bodyMediumOnPrimaryContainer,
                    ),
                    SizedBox(height: 23.v),
                    _buildWeek(
                      context,
                      label12: "Sun",
                      label13: "Mon",
                      label14: "Tue",
                      label15: "Wed",
                      label16: "Thu",
                      label17: "Fri",
                      label18: "Sat",
                    ),
                    SizedBox(height: 19.v),
                    Container(
                      padding: EdgeInsets.all(6.h),
                      decoration: AppDecoration.fillWhiteA,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "29",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 26.h),
                            child: Text(
                              "30",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 25.h),
                            child: Text(
                              "31",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Spacer(
                            flex: 23,
                          ),
                          Text(
                            "1",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 26,
                          ),
                          Text(
                            "2",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 24,
                          ),
                          Text(
                            "3",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 24,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 3.h),
                            child: Text(
                              "4",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 19.v),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 9.h,
                        vertical: 6.v,
                      ),
                      decoration: AppDecoration.fillWhiteA,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 2.h),
                            child: Text(
                              "5",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Spacer(
                            flex: 20,
                          ),
                          Text(
                            "6",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 20,
                          ),
                          Text(
                            "7",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 20,
                          ),
                          Text(
                            "8",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 20,
                          ),
                          Text(
                            "9",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 18,
                          ),
                          Text(
                            "10",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 26.h),
                            child: Text(
                              "11",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 19.v),
                    _buildWeek(
                      context,
                      label12: "12",
                      label13: "13",
                      label14: "14",
                      label15: "15",
                      label16: "16",
                      label17: "17",
                      label18: "18",
                    ),
                    SizedBox(height: 19.v),
                    _buildWeek(
                      context,
                      label12: "19",
                      label13: "20",
                      label14: "21",
                      label15: "22",
                      label16: "23",
                      label17: "24",
                      label18: "25",
                    ),
                    SizedBox(height: 19.v),
                    Container(
                      padding: EdgeInsets.all(6.h),
                      decoration: AppDecoration.fillWhiteA,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "26",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 25.h),
                            child: Text(
                              "27",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 25.h),
                            child: Text(
                              "28",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 25.h),
                            child: Text(
                              "29",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 26.h),
                            child: Text(
                              "30",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                          Spacer(
                            flex: 45,
                          ),
                          Text(
                            "1",
                            style: theme.textTheme.bodyMedium,
                          ),
                          Spacer(
                            flex: 54,
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 3.h),
                            child: Text(
                              "2",
                              style: theme.textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 12.v),
                  ],
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  /// Common widget
  Widget _buildWeek(
    BuildContext context, {
    required String label12,
    required String label13,
    required String label14,
    required String label15,
    required String label16,
    required String label17,
    required String label18,
  }) {
    return Container(
      padding: EdgeInsets.all(6.h),
      decoration: AppDecoration.fillWhiteA,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label12,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label13,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label14,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label15,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label16,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label17,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
          Text(
            label18,
            style: theme.textTheme.bodyMedium!.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
        ],
      ),
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
