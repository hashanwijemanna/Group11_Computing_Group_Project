import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/widgets/custom_elevated_button.dart';

class LoginHomeScreen extends StatelessWidget {
  const LoginHomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            backgroundColor: appTheme.blue800,
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(horizontal: 13.h, vertical: 10.v),
                child: Column(children: [
                  _buildWelcomeToNetRides(context),
                  Spacer(),
                  CustomElevatedButton(
                      text: "SIGN UP",
                      margin: EdgeInsets.symmetric(horizontal: 12.h),
                      buttonStyle:
                          CustomButtonStyles.outlineOnPrimaryContainerTL20,
                      buttonTextStyle: CustomTextStyles.bodyMediumLexendPrimary,
                      onPressed: () {
                        onTapSIGNUP(context);
                      }),
                  SizedBox(height: 45.v),
                  Text("Already a member",
                      style: CustomTextStyles.bodySmallWhiteA700),
                  SizedBox(height: 15.v),
                  GestureDetector(
                      onTap: () {
                        onTapTxtSIGNIN(context);
                      },
                      child: Text("SIGN IN",
                          style:
                              CustomTextStyles.bodyMediumLexendLightblue900)),
                  SizedBox(height: 26.v)
                ]))));
  }

  /// Section Widget
  Widget _buildWelcomeToNetRides(BuildContext context) {
    return SizedBox(
        height: 361.v,
        width: 330.h,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          Align(
              alignment: Alignment.topCenter,
              child: Container(
                  width: 330.h,
                  decoration: AppDecoration.outlineOnPrimaryContainer1,
                  child: Text("Welcome to \nNet Rides",
                      maxLines: null,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.headlineSmallWhiteA700_1))),
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                  height: 100.adaptSize,
                  width: 100.adaptSize,
                  decoration: AppDecoration.fillBlueGray.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder30),
                  child: CustomImageView(
                      imagePath: ImageConstant.imgWhatsappImage,
                      height: 83.v,
                      width: 100.h,
                      alignment: Alignment.topCenter)))
        ]));
  }

  /// Navigates to the signInOneScreen when the action is triggered.
  onTapSIGNUP(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInOneScreen);
  }

  /// Navigates to the signInScreen when the action is triggered.
  onTapTxtSIGNIN(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.signInScreen);
  }
}
