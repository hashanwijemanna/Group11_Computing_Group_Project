import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';
import 'package:thamal_s_application2/presentation/route_details_page/route_details_page.dart';
import 'package:thamal_s_application2/widgets/custom_bottom_bar.dart';

class StudentAdminProfileScreen extends StatelessWidget {
  StudentAdminProfileScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 10.h,
            vertical: 11.v,
          ),
          child: Column(
            children: [
              _buildMenuRow(context),
              SizedBox(height: 39.v),
              Text(
                "PROFILE",
                style: theme.textTheme.titleLarge,
              ),
              SizedBox(height: 28.v),
              Container(
                width: 116.h,
                margin: EdgeInsets.symmetric(horizontal: 112.h),
                padding: EdgeInsets.symmetric(
                  horizontal: 21.h,
                  vertical: 10.v,
                ),
                decoration: AppDecoration.fillBlueGray.copyWith(
                  borderRadius: BorderRadiusStyle.circleBorder58,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(height: 21.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgUserBlue80060x60,
                      height: 53.adaptSize,
                      width: 53.adaptSize,
                    ),
                    SizedBox(height: 6.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgCamera,
                      height: 15.adaptSize,
                      width: 15.adaptSize,
                      alignment: Alignment.centerRight,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 50.v),
              _buildNameRow(context),
              SizedBox(height: 13.v),
              _buildNicRow(context),
              SizedBox(height: 13.v),
              _buildUmisEmailRow(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.symmetric(horizontal: 12.h),
          child: _buildBottomBar(context),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 10.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgMenu,
            height: 12.v,
            width: 18.h,
            margin: EdgeInsets.symmetric(vertical: 14.v),
          ),
          Container(
            height: 40.adaptSize,
            width: 40.adaptSize,
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(
                20.h,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNameRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Name: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 64.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNicRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "NIC: ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 74.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildUmisEmailRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 10.h,
        right: 4.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "UMIS Email: : ",
            style: theme.textTheme.bodySmall,
          ),
          Container(
            height: 11.v,
            width: 230.h,
            margin: EdgeInsets.only(left: 31.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildBottomBar(BuildContext context) {
    return CustomBottomBar(
      onChanged: (BottomBarEnum type) {
        Navigator.pushNamed(
            navigatorKey.currentContext!, getCurrentRoute(type));
      },
    );
  }

  ///Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.User:
        return AppRoutes.routeDetailsPage;
      case BottomBarEnum.Bellring:
        return "/";
      case BottomBarEnum.Home:
        return "/";
      case BottomBarEnum.Bus:
        return "/";
      case BottomBarEnum.Vectorprimary:
        return "/";
      default:
        return "/";
    }
  }

  ///Handling page based on route
  Widget getCurrentPage(String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.routeDetailsPage:
        return RouteDetailsPage();
      default:
        return DefaultWidget();
    }
  }
}
