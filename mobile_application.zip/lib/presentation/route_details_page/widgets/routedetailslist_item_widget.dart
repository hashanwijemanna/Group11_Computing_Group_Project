import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';

// ignore: must_be_immutable
class RoutedetailslistItemWidget extends StatelessWidget {
  const RoutedetailslistItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          height: 70.v,
          width: 186.h,
          decoration: BoxDecoration(
            color: appTheme.blueGray100,
            borderRadius: BorderRadius.circular(
              5.h,
            ),
          ),
        ),
        CustomImageView(
          imagePath: ImageConstant.imgStarOutline,
          height: 24.adaptSize,
          width: 24.adaptSize,
          margin: EdgeInsets.symmetric(vertical: 23.v),
        ),
      ],
    );
  }
}
