import '../route_details_page/widgets/routedetailslist_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:thamal_s_application2/core/app_export.dart';

// ignore_for_file: must_be_immutable
class RouteDetailsPage extends StatelessWidget {
  const RouteDetailsPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillWhiteA,
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: 10.h,
              vertical: 15.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildMenuRow(context),
                SizedBox(height: 39.v),
                Container(
                  height: 25.v,
                  width: 150.h,
                  margin: EdgeInsets.only(left: 19.h),
                  decoration: BoxDecoration(
                    color: appTheme.blueGray100,
                    borderRadius: BorderRadius.circular(
                      10.h,
                    ),
                  ),
                ),
                SizedBox(height: 39.v),
                _buildRouteDetailsList(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildMenuRow(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: EdgeInsets.only(left: 18.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgMenu,
              height: 12.v,
              width: 18.h,
              margin: EdgeInsets.only(
                top: 20.v,
                bottom: 8.v,
              ),
            ),
            Container(
              height: 40.adaptSize,
              width: 40.adaptSize,
              decoration: BoxDecoration(
                color: appTheme.blueGray100,
                borderRadius: BorderRadius.circular(
                  20.h,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRouteDetailsList(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 19.h,
        right: 40.h,
      ),
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 49.v,
          );
        },
        itemCount: 5,
        itemBuilder: (context, index) {
          return RoutedetailslistItemWidget();
        },
      ),
    );
  }
}
