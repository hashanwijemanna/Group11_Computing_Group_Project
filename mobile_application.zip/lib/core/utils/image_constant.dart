class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Reports images
  static String imgSettings = '$imagePath/img_settings.svg';

  // First UI images
  static String imgFirstUi = '$imagePath/img_first_ui.png';

  // Sign-in One images
  static String imgVectorOnprimarycontainer =
      '$imagePath/img_vector_onprimarycontainer.svg';

  static String imgAccountoutline = '$imagePath/img_accountoutline.svg';

  static String imgUserOnprimarycontainer =
      '$imagePath/img_user_onprimarycontainer.svg';

  // Student-Dashboard images
  static String imgRectangle29 = '$imagePath/img_rectangle_29.png';

  // Student Administration-Home images
  static String imgRectangle53 = '$imagePath/img_rectangle_53.png';

  static String imgRectangle29100x100 =
      '$imagePath/img_rectangle_29_100x100.png';

  // Student Attendance images
  static String imgRectangle23120x120 =
      '$imagePath/img_rectangle_23_120x120.png';

  static String imgQrcodeScan = '$imagePath/img_qrcode_scan.svg';

  static String imgRectangle2450x50 = '$imagePath/img_rectangle_24_50x50.png';

  // Sign-up/student images
  static String imgMenuPrimary = '$imagePath/img_menu_primary.svg';

  static String imgUpload = '$imagePath/img_upload.svg';

  // Bus owner-Profile images
  static String imgTrainBus = '$imagePath/img_train_bus.svg';

  static String imgVectorOnprimarycontainer7x12 =
      '$imagePath/img_vector_onprimarycontainer_7x12.svg';

  // Common images
  static String imgWhatsappImage = '$imagePath/img_whatsapp_image.png';

  static String imgUser = '$imagePath/img_user.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgInfo = '$imagePath/img_info.svg';

  static String imgMenu = '$imagePath/img_menu.svg';

  static String imgSearch = '$imagePath/img_search.svg';

  static String imgRating = '$imagePath/img_rating.svg';

  static String imgBellRing = '$imagePath/img_bell_ring.svg';

  static String imgHome = '$imagePath/img_home.svg';

  static String imgBus = '$imagePath/img_bus.svg';

  static String imgVectorPrimary = '$imagePath/img_vector_primary.svg';

  static String imgMapMarker = '$imagePath/img_map_marker.svg';

  static String imgSearchLightBlue900 =
      '$imagePath/img_search_light_blue_900.svg';

  static String imgStarOutline = '$imagePath/img_star_outline.svg';

  static String imgGroup282 = '$imagePath/img_group_282.png';

  static String imgMenuBlue800 = '$imagePath/img_menu_blue_800.svg';

  static String imgSearchBlue800 = '$imagePath/img_search_blue_800.svg';

  static String imgRectangle16 = '$imagePath/img_rectangle_16.png';

  static String imgRectangle17 = '$imagePath/img_rectangle_17.png';

  static String imgRectangle21 = '$imagePath/img_rectangle_21.png';

  static String imgRectangle22 = '$imagePath/img_rectangle_22.png';

  static String imgRectangle23 = '$imagePath/img_rectangle_23.png';

  static String imgRectangle24 = '$imagePath/img_rectangle_24.png';

  static String imgRectangle28 = '$imagePath/img_rectangle_28.png';

  static String imgRectangle30 = '$imagePath/img_rectangle_30.png';

  static String imgUserBlue800 = '$imagePath/img_user_blue_800.svg';

  static String imgBellRingBlue800 = '$imagePath/img_bell_ring_blue_800.svg';

  static String imgHomeBlue800 = '$imagePath/img_home_blue_800.svg';

  static String imgBusBlue800 = '$imagePath/img_bus_blue_800.svg';

  static String imgVectorBlue800 = '$imagePath/img_vector_blue_800.svg';

  static String imgRectangle291 = '$imagePath/img_rectangle_29_1.png';

  static String imgUserBlue80060x60 = '$imagePath/img_user_blue_800_60x60.svg';

  static String imgVectorPrimary20x24 =
      '$imagePath/img_vector_primary_20x24.svg';

  static String imgComponent6 = '$imagePath/img_component_6.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgCamera = '$imagePath/img_camera.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
