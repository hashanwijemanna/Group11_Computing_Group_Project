import 'package:flutter/material.dart';
import 'package:thamal_s_application2/presentation/sign_in_screen/sign_in_screen.dart';
import 'package:thamal_s_application2/presentation/bus_details_screen/bus_details_screen.dart';
import 'package:thamal_s_application2/presentation/bus_details_each_screen/bus_details_each_screen.dart';
import 'package:thamal_s_application2/presentation/driver_details_screen/driver_details_screen.dart';
import 'package:thamal_s_application2/presentation/driver_details_each_screen/driver_details_each_screen.dart';
import 'package:thamal_s_application2/presentation/feedbacks_screen/feedbacks_screen.dart';
import 'package:thamal_s_application2/presentation/reports_screen/reports_screen.dart';
import 'package:thamal_s_application2/presentation/map_student_parent_screen/map_student_parent_screen.dart';
import 'package:thamal_s_application2/presentation/map_bus_owner_bus_driver_screen/map_bus_owner_bus_driver_screen.dart';
import 'package:thamal_s_application2/presentation/route_details_container_screen/route_details_container_screen.dart';
import 'package:thamal_s_application2/presentation/my_alerts_screen/my_alerts_screen.dart';
import 'package:thamal_s_application2/presentation/notifications_screen/notifications_screen.dart';
import 'package:thamal_s_application2/presentation/first_ui_screen/first_ui_screen.dart';
import 'package:thamal_s_application2/presentation/login_home_screen/login_home_screen.dart';
import 'package:thamal_s_application2/presentation/sign_in_one_screen/sign_in_one_screen.dart';
import 'package:thamal_s_application2/presentation/student_dashboard_screen/student_dashboard_screen.dart';
import 'package:thamal_s_application2/presentation/parent_home_screen/parent_home_screen.dart';
import 'package:thamal_s_application2/presentation/student_administration_home_screen/student_administration_home_screen.dart';
import 'package:thamal_s_application2/presentation/bus_owner_home_screen/bus_owner_home_screen.dart';
import 'package:thamal_s_application2/presentation/bus_driver_home_screen/bus_driver_home_screen.dart';
import 'package:thamal_s_application2/presentation/student_attendance_screen/student_attendance_screen.dart';
import 'package:thamal_s_application2/presentation/sign_up_student_screen/sign_up_student_screen.dart';
import 'package:thamal_s_application2/presentation/sign_up_parent_screen/sign_up_parent_screen.dart';
import 'package:thamal_s_application2/presentation/sign_up_admin_screen/sign_up_admin_screen.dart';
import 'package:thamal_s_application2/presentation/stu_ad_announcement_one_screen/stu_ad_announcement_one_screen.dart';
import 'package:thamal_s_application2/presentation/stu_ad_announcement_screen/stu_ad_announcement_screen.dart';
import 'package:thamal_s_application2/presentation/student_profile_screen/student_profile_screen.dart';
import 'package:thamal_s_application2/presentation/parent_profile_screen/parent_profile_screen.dart';
import 'package:thamal_s_application2/presentation/student_admin_profile_screen/student_admin_profile_screen.dart';
import 'package:thamal_s_application2/presentation/bus_owner_profile_screen/bus_owner_profile_screen.dart';
import 'package:thamal_s_application2/presentation/bus_driver_profile_screen/bus_driver_profile_screen.dart';
import 'package:thamal_s_application2/presentation/my_activity_student_screen/my_activity_student_screen.dart';
import 'package:thamal_s_application2/presentation/sign_up_bus_owner_screen/sign_up_bus_owner_screen.dart';
import 'package:thamal_s_application2/presentation/sign_up_bus_driver_screen/sign_up_bus_driver_screen.dart';
import 'package:thamal_s_application2/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String signInScreen = '/sign_in_screen';

  static const String busDetailsScreen = '/bus_details_screen';

  static const String busDetailsEachScreen = '/bus_details_each_screen';

  static const String driverDetailsScreen = '/driver_details_screen';

  static const String driverDetailsEachScreen = '/driver_details_each_screen';

  static const String feedbacksScreen = '/feedbacks_screen';

  static const String reportsScreen = '/reports_screen';

  static const String mapStudentParentScreen = '/map_student_parent_screen';

  static const String mapBusOwnerBusDriverScreen =
      '/map_bus_owner_bus_driver_screen';

  static const String routeDetailsPage = '/route_details_page';

  static const String routeDetailsContainerScreen =
      '/route_details_container_screen';

  static const String myAlertsScreen = '/my_alerts_screen';

  static const String notificationsScreen = '/notifications_screen';

  static const String firstUiScreen = '/first_ui_screen';

  static const String loginHomeScreen = '/login_home_screen';

  static const String signInOneScreen = '/sign_in_one_screen';

  static const String studentDashboardScreen = '/student_dashboard_screen';

  static const String parentHomeScreen = '/parent_home_screen';

  static const String studentAdministrationHomeScreen =
      '/student_administration_home_screen';

  static const String busOwnerHomeScreen = '/bus_owner_home_screen';

  static const String busDriverHomeScreen = '/bus_driver_home_screen';

  static const String studentAttendanceScreen = '/student_attendance_screen';

  static const String signUpStudentScreen = '/sign_up_student_screen';

  static const String signUpParentScreen = '/sign_up_parent_screen';

  static const String signUpAdminScreen = '/sign_up_admin_screen';

  static const String stuAdAnnouncementOneScreen =
      '/stu_ad_announcement_one_screen';

  static const String stuAdAnnouncementScreen = '/stu_ad_announcement_screen';

  static const String studentProfileScreen = '/student_profile_screen';

  static const String parentProfileScreen = '/parent_profile_screen';

  static const String studentAdminProfileScreen =
      '/student_admin_profile_screen';

  static const String busOwnerProfileScreen = '/bus_owner_profile_screen';

  static const String busDriverProfileScreen = '/bus_driver_profile_screen';

  static const String myActivityStudentScreen = '/my_activity_student_screen';

  static const String signUpBusOwnerScreen = '/sign_up_bus_owner_screen';

  static const String signUpBusDriverScreen = '/sign_up_bus_driver_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    signInScreen: (context) => SignInScreen(),
    busDetailsScreen: (context) => BusDetailsScreen(),
    busDetailsEachScreen: (context) => BusDetailsEachScreen(),
    driverDetailsScreen: (context) => DriverDetailsScreen(),
    driverDetailsEachScreen: (context) => DriverDetailsEachScreen(),
    feedbacksScreen: (context) => FeedbacksScreen(),
    reportsScreen: (context) => ReportsScreen(),
    mapStudentParentScreen: (context) => MapStudentParentScreen(),
    mapBusOwnerBusDriverScreen: (context) => MapBusOwnerBusDriverScreen(),
    routeDetailsContainerScreen: (context) => RouteDetailsContainerScreen(),
    myAlertsScreen: (context) => MyAlertsScreen(),
    notificationsScreen: (context) => NotificationsScreen(),
    firstUiScreen: (context) => FirstUiScreen(),
    loginHomeScreen: (context) => LoginHomeScreen(),
    signInOneScreen: (context) => SignInOneScreen(),
    studentDashboardScreen: (context) => StudentDashboardScreen(),
    parentHomeScreen: (context) => ParentHomeScreen(),
    studentAdministrationHomeScreen: (context) =>
        StudentAdministrationHomeScreen(),
    busOwnerHomeScreen: (context) => BusOwnerHomeScreen(),
    busDriverHomeScreen: (context) => BusDriverHomeScreen(),
    studentAttendanceScreen: (context) => StudentAttendanceScreen(),
    signUpStudentScreen: (context) => SignUpStudentScreen(),
    signUpParentScreen: (context) => SignUpParentScreen(),
    signUpAdminScreen: (context) => SignUpAdminScreen(),
    stuAdAnnouncementOneScreen: (context) => StuAdAnnouncementOneScreen(),
    stuAdAnnouncementScreen: (context) => StuAdAnnouncementScreen(),
    studentProfileScreen: (context) => StudentProfileScreen(),
    parentProfileScreen: (context) => ParentProfileScreen(),
    studentAdminProfileScreen: (context) => StudentAdminProfileScreen(),
    busOwnerProfileScreen: (context) => BusOwnerProfileScreen(),
    busDriverProfileScreen: (context) => BusDriverProfileScreen(),
    myActivityStudentScreen: (context) => MyActivityStudentScreen(),
    signUpBusOwnerScreen: (context) => SignUpBusOwnerScreen(),
    signUpBusDriverScreen: (context) => SignUpBusDriverScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
